import numpy as np
import scipy.sparse as sp
import torch
import scipy.io as io
import scipy.io as scio
import h5py
from sklearn.metrics import roc_auc_score
from sklearn.metrics import average_precision_score
from sklearn import metrics
from munkres import Munkres, print_matrix
from sklearn.cluster import KMeans
import torch.nn.functional as F
from scipy.sparse import csr_matrix
import warnings
from pygcn.metric import cal_clustering_metric_f
warnings.filterwarnings('ignore')

NGs = 'NGs'
NGs_c = 'NGs_c'

WebKB='WebKB'
WebKB_c='WebKB_c'

synthetic3d='synthetic3d'
synthetic3d_c='synthetic3d_c'

uci_digit='uci-digit'
uci_digit_c='uci-digit_c'

BDGP_fea='BDGP_fea'
BDGP_fea_c='BDGP_fea_c'

bbcsport='bbcsport_seg14of4'
bbcsport_c='bbcsport_seg14of4_c'

BBCSport2_fea_c='BBCSport2_fea_c'
BBCSport2_fea='BBCSport2_fea'


Flower17_fea_c='Flower17_fea_c'
Flower17_fea='Flower17_fea'

Sources_fea_c='3Sources_fea_c'
Sources_fea='3Sources_fea'

BBC2_fea_c='BBC2_fea_c'
BBC2_fea='BBC2_fea'

prokaryotic='prokaryotic'
prokaryotic_c='prokaryotic_c'

Mfeat_fea_c='Mfeat_fea_c'
Mfeat_fea='Mfeat_fea'

BBC3_fea_c='BBC3_fea_c'
BBC3_fea='BBC3_fea'

BBC4_fea_c='BBC4_fea_c'
BBC4_fea='BBC4_fea'

ForestTypes_fea='ForestTypes_fea'
ForestTypes_fea_c='ForestTypes_fea_c'

ORL_fea='ORL_fea'
ORL_fea_c='ORL_fea_c'

Texas_fea='Texas_fea'
Texas_fea_c='Texas_fea_c'

Washington_fea='Washington_fea'
Washington_fea_c='Washington_fea_c'

Wiki_fea='Wiki_fea'
Wiki_fea_c='Wiki_fea_c'

Wisconsin_fea='Wisconsin_fea'
Wisconsin_fea_c='Wisconsin_fea_c'

Yale_fea='Yale_fea'
Yale_fea_c='Yale_fea_c'

Leaves_c='100Leaves_c'
Leaves='100Leaves'


Dermatology_fea_c='Dermatology_fea_c'
Dermatology_fea='Dermatology_fea'

acm='acm'
acm_c='acm_c'

dataset={'0':'prokaryotic' , '1':'Mfeat_fea' , '2': 'ForestTypes_fea','3':'ORL_fea' , '4':'Texas_fea' , '5': 'Washington_fea','6':'Yale_fea' , '7':'100Leaves' , '8': 'Dermatology_fea','9':'BDGP_fea'}
dataset_c={'0':'prokaryotic_c' , '1':'Mfeat_fea_c' , '2': 'ForestTypes_fea_c','3':'ORL_fea_c' , '4':'Texas_fea_c' , '5': 'Washington_fea_c','6':'Yale_fea_c' , '7':'100Leaves_c' , '8': 'Dermatology_fea_c','9':'BDGP_fea_c'}


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def encode_onehot(labels):
    classes = set(labels)
    classes_dict = {c: np.identity(len(classes))[i, :] for i, c in
                    enumerate(classes)}
    labels_onehot = np.array(list(map(classes_dict.get, labels)),
                             dtype=np.int32)
    return labels_onehot

def dot_product(s):
    adj1 = F.softmax(F.relu(torch.mm(s, s.transpose(0, 1))), dim=1)
    return adj1

def load_data(l,num_nei):
    path='../data/{}.mat'.format(l)
    data = scio.loadmat(path)
    ##########Y##########
    Y = data['Y']
    Y = np.array(Y)
    Y = np.squeeze(Y)
    n=Y.shape[0]
    ########X和Z#############
    a = data['X']
    X = {}
    v = data['X'].shape[0]
    Indications={}
    index=data['index']
    ZV={}
    for i in range(v):
        # print('------------------------第 %5.4f 个视图' % (i + 1), end=' ')
        index_mat = csr_matrix(index[0][i]).toarray()
        index_mat = np.mat(index_mat, dtype=np.float32)
        Indication = np.zeros((n, index_mat.shape[0]))

        # print(c[1,0])
        for j in range(index_mat.shape[0]):
            Indication[int(index_mat[j,0])-1,j]=1
        # print(Indication)
        Indications.update({str(i): Indication})
        Indications[str(i)] = torch.FloatTensor(np.array(Indications[str(i)]))


    for i in range(v):
        h = csr_matrix(a[i][0]).toarray()
        c = np.mat(h, dtype=np.float32)
        c = normalize(c)  # 数据矩阵X
        X.update({str(i): c})
        X[str(i)] = torch.FloatTensor(np.array(X[str(i)]))
        ###该步骤优化的时间较长，若要缩短时间，请修改里面的迭代次数
        ZV[str(i)]=generateAnchorGraph2((Indications[str(i)].T)@X[str(i)], (Indications[str(i)].T)@X[str(i)], Indications[str(i)].shape[1], Indications[str(i)].shape[1], 0.01)
        ZV[str(i)] = torch.FloatTensor(np.array(ZV[str(i)].cpu()))
        ZV[str(i)]=Indications[str(i)]@ZV[str(i)]@(Indications[str(i)].T)
    A, S_inx = gen_A(num_nei, ZV)
    S_inx = torch.FloatTensor(np.array(S_inx))
    ################################A
    adj=sp.coo_matrix(A,dtype=np.float32)
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
    adj = normalize(adj + sp.eye(adj.shape[0]))
    adj= sparse_mx_to_torch_sparse_tensor((adj))
###############################Z
    for i in range(v):
        ZV[str(i)] = ZV[str(i)].T
        # print(torch.sum(ZV[str(i)], axis=0))
    #     for j in range(n):
    #         ZV[str(i)][j, j] = 0.005
    # ZV = gen_z(50, ZV)

    for i in range(v):
        ZV[str(i)] = torch.FloatTensor(np.array(ZV[str(i)]))

    return adj, X,Y,ZV,Indications,S_inx
#返回邻接矩阵，特征矩阵，标签，训练的标号，测试的标号

def normalize(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx

def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)

def A_TURE(A,Y,c):
    n=A.shape[0]
    # print(n)
    sum_a=0
    for i in range(n):
        for j in range(n):
            if A[i,j]==1 and Y[i]==Y[j]:
                sum_a=sum_a+1
    pre=sum_a/(c*n)
    return  pre

def cal_clustering_acc(true_label, pred_label):
    l1 = list(set(true_label))
    numclass1 = len(l1)

    l2 = list(set(pred_label))
    numclass2 = len(l2)
    if numclass1 != numclass2:
        print('Class Not equal, Error!!!!')
        return 0

    cost = np.zeros((numclass1, numclass2), dtype=int)
    for i, c1 in enumerate(l1):
        mps = [i1 for i1, e1 in enumerate(true_label) if e1 == c1]
        for j, c2 in enumerate(l2):
            mps_d = [i1 for i1 in mps if pred_label[i1] == c2]

            cost[i][j] = len(mps_d)

    # match two clustering results by Munkres algorithm
    m = Munkres()
    cost = cost.__neg__().tolist()

    indexes = m.compute(cost)

    # get the match results
    new_predict = np.zeros(len(pred_label))
    for i, c in enumerate(l1):
        # correponding label in l2:
        c2 = l2[indexes[i][1]]

        # ai is the index with label==c2 in the pred_label list
        ai = [ind for ind, elm in enumerate(pred_label) if elm == c2]
        new_predict[ai] = c

    acc = metrics.accuracy_score(true_label, new_predict)
    return acc

def cal_clustering_metric(truth, prediction):
    nmi = metrics.normalized_mutual_info_score(truth, prediction)
    acc = cal_clustering_acc(truth, prediction)
    return acc, nmi

def normalize(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx

def eProjSimplex(v):
    iter = 1
    k = 1
    v = torch.squeeze(v)
    n = v.shape[0]
    v0 = v - v.mean() + k / n
    c = v0.min()

    if c < 0:
        f = 1
        lambda_m = 0
        v1 = v0 - lambda_m
        while abs(f) > 1e-12:
            v1 = v0 - lambda_m
            posidx = (v1>0).nonzero()
            npos = torch.sum(posidx)
            g = -npos
            f = torch.sum(v1[posidx]) - k
            lambda_m = lambda_m - (f/g)
            iter = iter + 1
            if iter > 2000:
                v1[v1<0] = 0
                x = v1
                return x
        v1[v1<0] = 0
        x = v1
    else:
        x = v0
    return x
# def calDistances(X,Z):
#     return torch.sum(torch.pow(X.unsqueeze(1)-Z, 2), 2)

def calDistances(X, Z):
    return torch.sum(torch.pow(X.unsqueeze(1) - Z, 2), 2).to(device)


def generateAnchorGraph2(X, Z, n, m, para_lambda):
    distances = calDistances(X, Z).to(device)
    temp_zeros = torch.zeros_like(distances).to(device)
    temp_ones = torch.ones_like(distances).to(device)
    dis = -distances / (2 * para_lambda)
    s, index = torch.min(distances, dim=1)
    s = s.unsqueeze(1).repeat(1, m)
    iter_num = 8000
    k = 1
    v0 = dis - dis.mean(dim=1).unsqueeze(1).repeat(1, m) + k / m  # v0为nxm
    c, _ = v0.min(dim=1)  # c为nx1
    if para_lambda == 0:
        x = torch.where(distances == s, temp_ones, temp_zeros)
    else:
        if (c >= 0).all() > 0:
            x = F.normalize(v0, p=1, dim=1)
        else:
            f = torch.ones((n, 1))
            lambda_m = torch.zeros((n, m)).to(device)
            v1 = v0 - lambda_m
            for i in range(iter_num):
                v1 = v0 - lambda_m
                b = torch.diag(torch.linspace(1, m, m)).to(device)
                a = torch.tensor((v1 > 0) * 1, dtype=torch.float32).to(device)
                # a = a.cuda()
                posidx = torch.mm(a, b).to(device)
                g = -torch.sum(posidx + 1, dim=1)
                new_mat = torch.where(v1 > 0, v1, temp_zeros).to(device)
                f = torch.sum(new_mat, dim=1) - k
                f_div_g = (f / g).unsqueeze(1).repeat(1, m)
                lambda_m = lambda_m - f_div_g
            v1[v1 < 0] = 0
            x = v1

    return x

###### 获得NxN大小的Z矩阵--Graph ######
def generateGraph(X,Z,n,m,para_lambda):
    graph = torch.zeros([n, m])
    distances = calDistances(X,Z)
    #s, index = torch.min(distances, dim=1)

    for i in range(n):
        # if para_lambda == 0:
        #     for j in range(m):
        #         if distances[i,j]==s[i]:
        #             anchorgraph[i, j] = 1
        # else:
        graph[i,:] = eProjSimplex(-distances[i,:]/(2*para_lambda))
    return graph

def generateAnchorGraph(X,Z,n,m,para_lambda):
    anchorgraph = torch.zeros([n, m])
    #anchorgraph = anchorgraph.cuda()
    distances = calDistances(X,Z)
    s, index = torch.min(distances, dim=1)

    for i in range(n):
        if para_lambda == 0:
            for j in range(m):
                if distances[i,j]==s[i]:
                    anchorgraph[i, j] = 1
        else:
            anchorgraph[i,:] = eProjSimplex(-distances[i,:]/(2*para_lambda))
    return anchorgraph






def clustering(Y, Z, k_means=True, SC=True,SVD=True):
    n_clusters = np.unique(Y).shape[0]
    #print("n_clusters",n_clusters)
    if k_means:
        embedding = Z.cpu().detach().numpy()
        km = KMeans(n_clusters=n_clusters).fit(embedding)
        prediction = km.predict(embedding)
        acc, nmi, purity, fscore, precision, recall = cal_clustering_metric_f(Y, prediction, n_clusters)
        return acc, nmi, purity, fscore, precision, recall
    if SC:
        degree = torch.sum(Z, dim=1).pow(-0.5)
        L = (Z * degree).t() * degree
        L = L.cpu()
        _, vectors = L.symeig(True)
        indicator = vectors[:, -n_clusters:]
        indicator = indicator / (indicator.norm(dim=1)+10**-10).repeat(n_clusters, 1).t()
        indicator = indicator.cpu().numpy()
        km = KMeans(n_clusters=n_clusters).fit(indicator)
        prediction = km.predict(indicator)
        acc, nmi,purity, fscore, precision, recall = cal_clustering_metric_f(Y, prediction,n_clusters)
        return acc, nmi,purity, fscore, precision, recall
    if SVD:
        U = SVD_K(Z, n_clusters)
        kmeans = KMeans(n_clusters=n_clusters).fit(U)
        y_pred = kmeans.labels_
        acc, nmi, purity, fscore, precision, recall = cal_clustering_metric_f(Y, y_pred, n_clusters)
        return acc, nmi, purity, fscore, precision, recall
def SVD_K(A,K):
    A = np.array(A, dtype=np.float64)
    sigma, V = np.linalg.eig(A.T @ A)
    arg_sort = np.argsort(sigma)[::-1]
    sigma = np.sort(sigma)[::-1]
    V = V[:, arg_sort]
    sigma[sigma == 0] = 1
    sigma_sqrt = 1 / np.sqrt(sigma)
    sigma_sqrt[sigma_sqrt == 1] = 0
    sigma_sqrt = np.sort(sigma)[::1]
    sigma_inv = np.diag(sigma_sqrt)
    U = (A @ V.T)[:,0:K] @ sigma_inv[0:K,0:K]
    return U
#####################生成A和邻居化的z###############################

def gen_z(k,Z):
    Z_nei = {}
    index_k = {}
    for v in range(len(Z)):
        Z[str(v)] = np.array(Z[str(v)])
        # Lst = List[:]  # 对列表进行浅复制，避免后面更改原列表数据
        z_k = np.zeros(Z[str(v)].shape)
        for j in range(Z[str(v)].shape[0]):
            # print("j",j)
            Lst2 = Z[str(v)][j].tolist()
            # print(Lst2)
            l = []
            for i in range(k):
                index_i = Lst2.index(max(Lst2))  # 得到列表的最小值，并得到该最小值的索引
                # print("最大值的索引",index_i)
                l.append(index_i)
                Lst2[index_i] = float('-inf')  # 将遍历过的列表最小值改为无穷大，下次不再选择
            z_k [j][l] = Z[str(v)][j][l]
            # index_k.update({str(j): l})
        z_k = normalize(z_k)
        Z_nei.update({str(v): z_k})
        Z_nei[str(v)] = torch.FloatTensor(np.array(Z_nei[str(v)]))
    return Z_nei

def gen_A(m,Z):
    List = np.array(Z[str(0)])
    Z_AVG = np.zeros(List.shape)
    Z_AVG = torch.FloatTensor(np.array( Z_AVG))
    for v in range(len(Z)):
        Z_AVG=Z_AVG+Z[str(v)]
    Z_AVG=Z_AVG/v
    A = np.zeros(Z_AVG.shape)
    print(A.shape)
    smp=Z_AVG.shape[0]

    S_inx = np.zeros([smp,m])
    print(S_inx.shape)
    for j in range(Z_AVG.shape[0]):
        Lst2 = Z_AVG[j].tolist()
        l = []
        for i in range(m):
            index_i = Lst2.index(max(Lst2))  # 得到列表的最小值，并得到该最小值的索引
            l.append(index_i)
            Lst2[index_i] = float('-inf')  # 将遍历过的列表最小值改为无穷大，下次不再选择
            if i < m:
                A[j][l] = 1
                S_inx[j][i]=index_i
    return A,S_inx

def gen_weight_A(m,Z):
    List = np.array(Z[str(0)])
    Z_AVG = np.zeros(List.shape)
    Z_AVG = torch.FloatTensor(np.array( Z_AVG))
    for v in range(len(Z)):
        Z_AVG=Z_AVG+Z[str(v)]
    Z_AVG=Z_AVG/v
    A = []
    A = np.zeros(Z_AVG.shape)
    for j in range(Z_AVG.shape[0]):
        Lst2 = Z_AVG[j].tolist()
        l = []
        for i in range(m):
            index_i = Lst2.index(max(Lst2))  # 得到列表的最小值，并得到该最小值的索引
            l.append(index_i)
            A[j][index_i] = Lst2[index_i]
            Lst2[index_i] = float('-inf')  # 将遍历过的列表最小值改为无穷大，下次不再选择
    return A



def Purity_score(y_true, y_pred):
    """Purity score
        Args:
            y_true(np.ndarray): n*1 matrix Ground truth labels
            y_pred(np.ndarray): n*1 matrix Predicted clusters

        Returns:
            float: Purity score
    """
    # matrix which will hold the majority-voted labels
    y_voted_labels = np.zeros(y_true.shape)
    # Ordering labels
    ## Labels might be missing e.g with set like 0,2 where 1 is missing
    ## First find the unique labels, then map the labels to an ordered set
    ## 0,2 should become 0,1
    labels = np.unique(y_true)
    ordered_labels = np.arange(labels.shape[0])
    for k in range(labels.shape[0]):
        y_true[y_true==labels[k]] = ordered_labels[k]
    # Update unique labels
    labels = np.unique(y_true)
    # We set the number of bins to be n_classes+2 so that
    # we count the actual occurence of classes between two consecutive bins
    # the bigger being excluded [bin_i, bin_i+1]
    bins = np.concatenate((labels, [np.max(labels)+1]), axis=0)

    for cluster in np.unique(y_pred):
        hist, _ = np.histogram(y_true[y_pred==cluster], bins=bins)
        # Find the most present label in the cluster
        winner = np.argmax(hist)
        y_voted_labels[y_pred==cluster] = winner

    purity = metrics.accuracy_score(y_true, y_voted_labels)
    return purity

if __name__ == "__main__":
    load_data(NGs)
