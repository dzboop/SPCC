import torch.nn as nn
import torch.nn.functional as F
from pygcn.layers import GraphConvolution
import scipy.io as io
from pygcn.mix import DirichletGaussianLayer
class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(GCN, self).__init__()

        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, nclass)
        self.dropout = dropout

    def forward(self, x, adj):
        x1 = F.relu(self.gc1(x, adj))
        fea = F.dropout(x1, self.dropout, training=self.training)
        x = self.gc2(fea, adj)
        # print("映射x",x)
        return F.softmax(x, dim=1),F.softmax(fea,dim=1)

#
class vcc(nn.Module):
    def __init__(self, view, features,dim ):
        super(vcc, self).__init__()

        self.GCNS = []
        for v in range(view):
            self.GCNS.append(GCN(nfeat=features[str(v)].shape[1],#输入层神经元个数    维度
                                nhid=dim,#隐藏层神经元个数
                                nclass=features[str(v)].shape[0],#输出层的个数    样本点的个数
                                #nclass=3,
                                dropout=0))
        self.GCNS = nn.ModuleList(self.GCNS)

        self.view = view
    def forward(self, features, adj):
        qs = []
        feats=[]
        zs = []
        for v in range(self.view):
            x = features[str(v)]
            z,feat = self.GCNS[v](x,adj)
            feats.append(feat)
            zs.append(z)
        return zs,feats
