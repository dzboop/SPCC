
import numpy as np
# 通过scipy.io转换：
import scipy.io as io
numpy_file = np.load('E:\\cluster data\\graph data\\pubmed\\pubmed_feat.npy')
numpy_file2 = np.load('E:\\cluster data\\graph data\\pubmed\\pubmed_label.npy')
numpy_file3 = np.load('E:\\cluster data\\graph data\\pubmed\\pubmed_adj.npy')
io.savemat('pubmed.mat', {'data_x': numpy_file,'data_y': numpy_file2,'A': numpy_file3})
