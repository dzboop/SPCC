from __future__ import division
from __future__ import print_function
from tqdm import tqdm
import scipy.sparse as sp
import warnings
import time
import argparse
import numpy as np
##########纯重建使用A
import torch.nn as nn
import torch
import torch.optim as optim
from pygcn.utils2 import load_data, clustering
from pygcn.models import vcc
from loss import Loss
from torch.nn.functional import normalize
warnings.filterwarnings('ignore')



datas={'0':'ORL_mtv' }

parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--fastmode', action='store_true', default=False,
                    help='Validate during training pass.')
parser.add_argument('--seed', type=int, default=42, help='Random seed.')
parser.add_argument('--epochs', type=int, default=590,
                    help='Number of epochs to train.')
parser.add_argument('--epochs2', type=int, default=200,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.005,
                    help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=64,
                    help='Number of hidden units.')
parser.add_argument('--dropout', type=float, default=0,
                    help='Dropout rate (1 - keep probability).')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()


np.random.seed(args.seed)
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)

def gen_weight_A(m,Z):
    List = np.array(Z[str(0)])
    Z_AVG = np.zeros(List.shape)
    Z_AVG = torch.FloatTensor(np.array( Z_AVG))
    for v in range(len(Z)):
        Z_AVG=Z_AVG+Z[str(v)]
    Z_AVG=Z_AVG/v
    A = []
    A = np.zeros(Z_AVG.shape)
    for j in range(Z_AVG.shape[0]):
        Lst2 = Z_AVG[j].tolist()
        l = []
        for i in range(m):
            index_i = Lst2.index(max(Lst2))  # 得到列表的最小值，并得到该最小值的索引
            l.append(index_i)
            A[j][index_i] = Lst2[index_i]
            Lst2[index_i] = float('-inf')  # 将遍历过的列表最小值改为无穷大，下次不再选择
    return A

def torch_normalize(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx

def gen_z(k,Z):
    Z_nei = {}
    index_k = {}
    for v in range(len(Z)):
        Z[str(v)] = np.array(Z[str(v)])
        # Lst = List[:]  # 对列表进行浅复制，避免后面更改原列表数据
        z_k = np.zeros(Z[str(v)].shape)
        for j in range(Z[str(v)].shape[0]):
            # print("j",j)
            Lst2 = Z[str(v)][j].tolist()
            # print(Lst2)
            l = []
            for i in range(k):
                index_i = Lst2.index(max(Lst2))  # 得到列表的最小值，并得到该最小值的索引
                # print("最大值的索引",index_i)
                l.append(index_i)
                Lst2[index_i] = float('-inf')  # 将遍历过的列表最小值改为无穷大，下次不再选择
            z_k [j][l] = Z[str(v)][j][l]
            # index_k.update({str(j): l})
        z_k = normalize(z_k)
        Z_nei.update({str(v): z_k})
        Z_nei[str(v)] = torch.FloatTensor(np.array(Z_nei[str(v)]))
    return Z_nei

def compute_mse_loss_on_cuda(y_pred, y_true):
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA不可用，无法在CUDA上进行计算。")
    y_pred = y_pred.cuda()
    y_true = y_true.cuda()
    mse_loss_fn = nn.MSELoss(reduction = 'sum')

    n_y=y_true.shape[1]
    loss = n_y*n_y*mse_loss_fn(y_pred, y_true)
    return loss


def gen_A2(m,Z):
    List = np.array(Z[str(0)])
    Z_AVG = np.zeros(List.shape)
    Z_AVG = torch.FloatTensor(np.array( Z_AVG))
    for v in range(len(Z)):
        Z_AVG=Z_AVG+Z[str(v)]
    Z_AVG=Z_AVG/len(Z)
    A = []
    A = np.zeros(Z_AVG.shape)
    for j in range(Z_AVG.shape[0]):
        Lst2 = Z_AVG[j].tolist()
        l = []
        for i in range(m):
            index_i = Lst2.index(max(Lst2))  # 得到列表的最小值，并得到该最小值的索引
            l.append(index_i)
            Lst2[index_i] = float('-inf')  # 将遍历过的列表最小值改为无穷大，下次不再选择
            if i < m:
                A[j][l] = 1

    return A



def train(epoch,features,adj,Q,Indications,S_inx,b,alph,beta):####
    outputs = {}
    t = time.time()
    # loss_sum=0
    outputs3 = torch.zeros((n, n)).cuda()
    outputs4= torch.zeros((n, n_clusters)).cuda()
    zs,feats= model(features, adj)
    loss_list1 = []
    loss_list2 = []
    loss_list3 = []
    for i in range(v):
        for w in range(i + 1, v):
            loss_list1.append(criterion.contrastive_loss(feats[i], feats[w]))
            loss_list2.append(criterion.forward_label(feats[i], feats[w]))
        outputs4=outputs4+feats[i]
        outputs3 = outputs3 + zs[i]
        c=Indications[str(i)].T
        a=c@(zs[i])
        g=c@(Q[str(i)])
        kl = compute_mse_loss_on_cuda(a, g)
        loss_list3.append(kl)
    loss_S_re = sum(loss_list3)+alph*sum(loss_list1)+beta*sum(loss_list2)
    loss_all=loss_S_re
    optimizer.zero_grad()
    loss_all.backward()
    optimizer.step()
    output3 = (outputs3 + outputs3.T) / 2
    output3 = torch.FloatTensor(output3.cpu().detach().numpy())
    acc_o, nmi_o, purity, fscore, precision, recall = clustering(Y, output3, k_means=False, SC=True,SVD=False)
    if epoch == args.epochs - 1:
        print('SC --- ACC: %5.4f, NMI: %5.4f,purity: %5.4f, fscore: %5.4f, precision: %5.4f, recall: %5.4f' % (
        acc_o, nmi_o, purity, fscore, precision, recall))


nei_shu=[5]
# alphs=[0.001,0.01,0.1,10,100,1000]
# betas=[0.001,0.01,0.1,10,100,1000]
alphs=[0.001]
betas=[0.1]
for alph in alphs:
    for beta in betas:
        for t in nei_shu:
            for p in range(0,1):
                for indx in [9]:
                    linshi = datas[str(p)] + '_Per0.' + str(indx)
                    print(linshi)
                    adj, features,Y,ZV,Indications,S_inx= load_data(linshi,t)
                    v=len(features)
                    n_clusters = np.unique(Y).shape[0]
                    n=ZV[str(0)].shape[0]
                    accs = {}
                    nmis = {}
                    purs={}
                    fscs={}
                    precs={}
                    recs={}
                    acc = []
                    nmi = []
                    pur=[]
                    fsc=[]
                    prec=[]
                    # loss_j=[]
                    rec=[]
                    model = vcc(view=v,  # 输入层神经元个数    维度
                                features=features,
                                dim=n_clusters)
                    optimizer = optim.Adam(model.parameters(),
                                           lr=args.lr, weight_decay=args.weight_decay)

                    for i in range(v):
                        if args.cuda:
                            model.cuda()
                            features[str(i)] = features[str(i)].cuda()
                            adj = adj.cuda()
                            criterion = Loss(n, 0.5, 0.5,
                                             0.5).cuda()
                            Indications[str(i)] = Indications[str(i)].cuda()
                            ZV[str(i)] = ZV[str(i)].cuda()
                            S_inx = S_inx.cuda()
                    t_total = time.time()
                    for epoch in tqdm(range(args.epochs), desc="Training Progress"):
                        train(epoch, features, adj, ZV,Indications,S_inx,t,alph,beta)
